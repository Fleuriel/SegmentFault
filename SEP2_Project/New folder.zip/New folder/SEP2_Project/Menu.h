#pragma once


void Menu_Load(void);
void Menu_Init(void);
void Menu_Update(void);
void Menu_Draw(void);
void Menu_Free(void);
void Menu_Unload(void);