#pragma once





enum
{
	// list of all game states 
	MENU = 0,

	//Start Game
	PLAY,
	// special game state. Do not change
	RESTART,

	QUIT

};