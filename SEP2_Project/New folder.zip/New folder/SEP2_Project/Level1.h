#pragma once

void Level_1_Load(void);
void Level_1_Init(void);
void Level_1_Update(void);
void Level_1_Draw(void);
void Level_1_Free(void);
void Level_1_Unload(void);