//
//#include "Controls.hpp"
//
//int x, y, z, r;
//void userInput(int num)
//{
//
//	if (num == AEInputCheckCurr(AEVK_RIGHT))
//	{
//		x += 5.0f;
//		std::cout << "x: " << x << ' ' << "y: " << y << ' ' << "z: " << z << ' ' << "r: " << r << '\n';
//		//			y = x;
//	}
//	if (num == AEInputCheckCurr(AEVK_LEFT))
//	{
//		x -= 5.0f;
//		std::cout << "x: " << x << ' ' << "y: " << y << ' ' << "z: " << z << ' ' << "r: " << r << '\n';
//		//			y = x;
//	}
//	if (num == AEInputCheckCurr(AEVK_DOWN))
//	{
//		y -= 5.0f;
//		std::cout << "x: " << x << ' ' << "y: " << y << ' ' << "z: " << z << ' ' << "r: " << r << '\n';
//	}
//	if (num == AEInputCheckCurr(AEVK_UP))
//	{
//		y += 5.0f;
//		std::cout << "x: " << x << ' ' << "y: " << y << ' ' << "z: " << z << ' ' << "r: " << r << '\n';
//	}
//	if (num == AEInputCheckCurr(AEVK_A))
//	{
//		r -= 0.01f;
//
//		std::cout << "x: " << x << ' ' << "y: " << y << ' ' << "z: " << z << ' ' << "r: " << r << '\n';
//	}
//	if (num == AEInputCheckCurr(AEVK_D))
//	{
//		r += 0.01f;
//		std::cout << "x: " << x << ' ' << "y: " << y << ' ' << "z: " << z << ' ' << "r: " << r << '\n';
//	}
//	if (num == AEInputCheckCurr(AEVK_1))
//	{
//		z -= 1.0f;
//
//		std::cout << "x: " << x << ' ' << "y: " << y << ' ' << "z: " << z << ' ' << "r: " << r << '\n';
//	}
//	if (num == AEInputCheckCurr(AEVK_2))
//	{
//		z += 1.0f;
//
//		std::cout << "x: " << x << ' ' << "y: " << y << ' ' << "z: " << z << ' ' << "r: " << r << '\n';
//	}
//	if (num == AEInputCheckCurr(AEVK_R))
//	{
//		z = 100.0f;
//
//		std::cout << "x: " << x << ' ' << "y: " << y << ' ' << "z: " << z << ' ' << "r: " << r << '\n';
//	}
//}