#pragma once

#include "AEEngine.h"

#include <iostream>


void userInput(int num);