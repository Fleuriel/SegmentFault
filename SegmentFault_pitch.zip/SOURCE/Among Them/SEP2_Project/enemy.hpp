#pragma once

struct enemyCoord;
void Enemy(struct enemyCoord AI, f32 playerX, f32 playerY);
